Paddy Doctor Q1 — Notebook 06
P4 Cross-Cultivar Generalization Benchmark
30 full epochs, no early stopping
Timestamp: 20260822_014632

Training design:
- 4 architectures x 3 seeds x 2 train domains = 24 trainings.
- Every checkpoint evaluated on ADT45 and OTHER = 48 evaluations.

Protocol mapping:
- P4A: ADT45 -> OTHER (cross-domain)
- P4B: ADT45 -> ADT45 (control)
- P4C: OTHER -> ADT45 (cross-domain)
- P4D: OTHER -> OTHER (control)

Important interpretation:
P4 is class-matched but not exact-age-matched. Phenological confounding is addressed in P5.

Checkpoints are NOT inside this ZIP.
They remain in Google Drive under models/06_P4_cross_cultivar_30ep_noES/.
