Paddy Doctor Q1 — Notebook 05
P1 Clean IID CNN vs Transformer Benchmark — definitive 30-epoch horizon
Timestamp: 20260821_211752

Checkpoints are NOT inside this ZIP.
They remain in Google Drive under models/05_P1_30ep_noES/.
