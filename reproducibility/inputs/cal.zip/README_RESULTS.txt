Paddy Doctor Q1 — Notebook 09
Calibration and Reliability Under Domain Shift

Temperature scaling fitted on validation only.
Test never used for calibration fitting.
Includes P1, P4 and P5.
Metrics: ECE, MCE, NLL, Brier, confidence-accuracy gap.
Includes fixed-target domain-shift calibration analysis.
