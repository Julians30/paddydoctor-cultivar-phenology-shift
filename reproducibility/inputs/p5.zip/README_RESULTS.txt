Paddy Doctor Q1 — Notebook 07
P5 Exact-Age-Matched Cross-Cultivar Sensitivity Benchmark
30 full epochs, no early stopping
Timestamp: 20260822_031250

Training design:
- 4 architectures x 3 seeds x 2 train domains = 24 trainings.
- Every checkpoint evaluated on ADT45 and OTHER = 48 evaluations.

Protocol mapping:
- P5A: ADT45 -> OTHER (exact-age-matched cross-domain)
- P5B: ADT45 -> ADT45 (age-matched in-domain control)
- P5C: OTHER -> ADT45 (exact-age-matched cross-domain)
- P5D: OTHER -> OTHER (age-matched in-domain control)

Important interpretation:
P5 is exactly matched by disease label and plant age across domains. It is a sensitivity benchmark and does not control all possible confounders.

Checkpoints are NOT inside this ZIP.
They remain in Google Drive under models/07_P5_exact_age_matched_30ep_noES/.
